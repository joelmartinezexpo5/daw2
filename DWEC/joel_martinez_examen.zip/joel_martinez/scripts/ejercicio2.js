'use strict'

const $yedra = (function () {
    let alumno = [

        {
            nombre: 'Joel',
            nota: 10,
            modulo: DWEC,
            convocatorias: 1
        },
        {
            nombre: 'Edgar',
            nota: 7,
            modulo: DWES,
            convocatorias: 2
        },
        {
            nombre: 'Javier',
            nota: 5,
            modulo: DWEC,
            convocatorias: 1
        },
        {
            nombre: 'Maria',
            nota: 2,
            modulo: DWES,
            convocatorias: 4
        },
        {
            nombre: 'Cristina',
            nota: 6,
            modulo: DWEC,
            convocatorias: 3
        }
    ]
})