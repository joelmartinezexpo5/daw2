<?php
namespace App\Interface;

interface ProductoRepositoryInterface{
    
    public function crear(Productos $producto):bool;
    public function listar():array;
}