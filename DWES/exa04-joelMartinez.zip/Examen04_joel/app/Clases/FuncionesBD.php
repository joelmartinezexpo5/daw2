<?php
namespace App\Clases;

use PDO;
use App\Clases\ConexionBD;

class FuncionesBD{

    public static function getProductos(){
        $conexion = ConexionBD::getConnection();
        $productos = [];

        $resultado = $conexion->query('SELECT nombre, descripcion, precio, familia, imagenId FROM productos');
        while($registro = $resultado->fetch(PDO::FETCH_ASSOC)){
            $productos[] = [
                'nombre' => $registro['nombre'],
                'descripcion' => $registro['descripcion'],
                'precio' => $registro['precio'],
                'familia' => $registro['familia'],
                'imagenId' => $registro['imagenId'],
            ];
        }

        return $productos;
    }

    public static function crearProducto($nombre, $descripcion, $precio, $familia, $imagenId){
        $conexion = ConexionBD::getConnection();

        $resultado = $conexion->prepare('INSERT INTO productos (nombre, descripcion, precio, familia, imagenId) VALUES (:nombre, :descripcion, :precio, :familia, :imagenId)');
        $resultado->bindParam(':nombre', $nombre);
        $resultado->bindParam(':descripcion', $descripcion);
        $resultado->bindParam(':precio', $precio);
        $resultado->bindParam(':familia', $familia);
        $resultado->bindParam(':imagenId', $imagenId);
        $resultado->execute();
    }
}
