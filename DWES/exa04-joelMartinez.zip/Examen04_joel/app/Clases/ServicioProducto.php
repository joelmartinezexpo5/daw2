<?php
namespace App\Clases;

use App\Interface\ProductoRepositoryInterface;

class ServicioProducto{
    private ProductoRepositoryInterface $interfaz;
    
    public function __construct(ProductoRepositoryInterface $interfaz){
        $this->interfaz = $interfaz;
    }

    public function crear(Productos $producto):bool{
        return $this->interfaz->crear($producto);
    }
    public function listar():array{
        return $this->interfaz->listar();
    }
}