<?php
namespace App\Clases;

class Productos{
    private int $id; 	
    private String $nombre; 	
    private String $descripcion; 	
    private int $precio; 	
    private Familias $familia; 	
    private int $imagenId;
    
    function __construct(int $id, String $nombre, String $descripcion, int $precio, Familias $familia, int $imagenId){
        $this->id=$id;
        $this->nombre=$nombre;
        $this->descripcion=$descripcion;
        $this->precio=$precio;
        $this->familia=$familia;
        $this->imagenId=$imagenId;
    }

    function getId(){
        return $this->id;
    }

    function getNombre(){
        return $this->nombre;
    }

    function getDescripcion(){
        return $this->descripcion;
    }

    function getPrecio(){
        return $this->precio;
    }

    function getFamilia(){
        return $this->familia;
    }

    function getImagenId(){
        return $this->imagenId;
    }
}