<?php
require_once __DIR__ . '/../vendor/autoload.php';

use App\FuncionesBD;

if($_SERVER['REQUEST_METHOD']==='POST'){
    $nombre = $_POST['nombre'] ?? null;
    $descripcion = $_POST['descripcion'] ?? null;
    $precio = $_POST['precio'] ?? null;
    $familia = $_POST['familia'] ?? null;
    $imagenId = $_POST['imagenId'] ?? null;
    
    FuncionesBD::crearProducto($nombre, $descripcion, $precio, $familia, $imagenId);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Crear producto</h1>
    <form action="" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>
        <br>
        <label for="descripcion">Descripcion:</label>
        <input type="text" name="descripcion" required>
        <br>
        <label for="precio">Precio</label>
        <input type="number" name="precio" required>
        <br>
        <label for="familia">Familia:</label>
        <input type="text" name="familia" required>
        <br>
        <label for="imagenId">ImagenId:</label>
        <input type="number" name="imagenId" required>
        <br>
        <button type="submit">Crear</button>
    </form>
</body>
</html>