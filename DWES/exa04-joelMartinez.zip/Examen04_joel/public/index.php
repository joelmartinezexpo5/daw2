<?php
require_once __DIR__ . '/../vendor/autoload.php';

use App\Clases\FuncionesBD;

$productos = FuncionesBD::getProductos();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Listado de productos</h1>
    <table border="1px solid black">
        <tr>
            <td>Nombre</td>
            <td>Precio</td>
            <td>Acciones</td>
        </tr>
        <tr>
            <?php foreach($productos as $producto):?>
                <td><?=htmlspecialchars($producto['nombre'])?></td>
                <td><?=htmlspecialchars($producto['precio'])?></td>
                <td><a href="./detalle.php">Mas informacion</a></td>
        </tr>
        <?php endforeach;?>
    </table>

    <a href="./crear.php">Crear Producto</a>
</body>
</html>