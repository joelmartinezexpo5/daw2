    <?php $__env->startSection('titulo', 'Create'); ?>
    <?php $__env->startSection('contenido'); ?>
    <h1 class="text-3xl font-bold underline">Creacion de animales</h1>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_zoologico\resources\views/animales/create.blade.php ENDPATH**/ ?>