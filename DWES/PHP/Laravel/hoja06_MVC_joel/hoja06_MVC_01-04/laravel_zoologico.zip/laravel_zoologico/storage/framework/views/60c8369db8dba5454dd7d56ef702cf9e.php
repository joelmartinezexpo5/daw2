<footer>
    <div class="animate_top">
        <p>&copy; 2022 CIC. Reservado todos los derechos</p>
      </div>
</footer>
<?php /**PATH C:\xampp\htdocs\laravel_zoologico\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>