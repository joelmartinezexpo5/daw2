<!DOCTYPE html>
<html lang="en">
<head <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    <?php $__env->startSection('titulo', 'Zoologico'); ?>
    <?php $__env->startSection('contenido'); ?>
    <h1 class="text-3xl font-bold underline">Pagina principal</h1>
    <?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_zoologico\resources\views/Inicio.blade.php ENDPATH**/ ?>