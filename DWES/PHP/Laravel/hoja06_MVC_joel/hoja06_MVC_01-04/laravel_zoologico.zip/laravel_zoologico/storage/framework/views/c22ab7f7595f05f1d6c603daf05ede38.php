    <?php $__env->startSection('titulo', 'Zoologico-Mostrar el animal'.$animal); ?>
    <?php $__env->startSection('contenido'); ?>
    <h1 class="text-3xl font-bold underline">Mostrar el <?php echo e($animal); ?></h1>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_zoologico\resources\views/animales/show.blade.php ENDPATH**/ ?>