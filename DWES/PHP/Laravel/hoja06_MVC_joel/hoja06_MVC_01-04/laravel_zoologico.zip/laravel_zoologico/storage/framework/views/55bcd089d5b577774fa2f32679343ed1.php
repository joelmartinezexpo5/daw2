    <?php $__env->startSection('titulo', 'Index'); ?>
    <?php $__env->startSection('contenido'); ?>
    <h1 class="text-3xl font-bold underline">Listado de animales</h1>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_zoologico\resources\views/animales/index.blade.php ENDPATH**/ ?>